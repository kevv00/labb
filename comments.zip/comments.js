module.exports = {
getComments(req, res) {
},
addComment(req, res) {
},
updateComment(req, res) {
},
removeComment(req, res) {
}
}
